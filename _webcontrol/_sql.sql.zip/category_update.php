<?php
require_once("../conn.php");
        function clean_up($value){
            $value=trim($value);
            $value=htmlspecialchars($value);
            $value=strip_tags($value);
            return $value;
        }
if(isset($_POST['log'])){	
    $query=$conn->prepare("update categories set name=?,updated_at=? where id=?");
    $query->bind_param('ssi',$name,$updated_at,$id);
    $id=clean_up($_POST['id']);
    $name=clean_up($_POST['name']);
    $updated_at;
    if($query->execute()){
        $_SESSION['msgs']="Category Updated";
    }else{
        $_SESSION['msgs']="Failed to update category";
    }    
    echo "<script>history.back();</script>";
}else{
	header("Location: index");
}
 ?>
