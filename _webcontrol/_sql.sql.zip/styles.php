  <meta name="description" content="">
  <meta name="author" content="">

  <title>Blaise Autocare | Admin Dashboard</title>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
  <link href="../css/sweetalert2.min.css" rel="stylesheet">
  <link href="../css/toastr.min.css" rel="stylesheet">
  <link rel="icon" href="../assets/images/slider/logow.png">
  <link rel="stylesheet" href="../datepicker/jquery-ui.css">
  <style>
 
input[type='number'] {
    -moz-appearance:textfield;
}
input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
#content-wrapper{
  margin-top:50px;
}
.carousel-item img{
  height:400px;
  width:400px;
}
.carousel-inner{
  height:400px;
  width:400px;
}
.carousel{
  height:400px;
  width:400px;
}
.carousel-indicators li{
  background:red;
}
.tasha span{
  font-weight:bold;
  margin-right:20px;
}
  </style>