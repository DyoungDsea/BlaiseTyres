<?php

    require("../conn.php");

    if($_SERVER["REQUEST_METHOD"]=="POST"):
        if(isset($_POST['updated'])){

    if(!empty($_POST["desc"])){
        $desc = $conn->real_escape_string($_POST["desc"]);
    }

    $id = $conn->real_escape_string(test_values($_POST["id"]));

    
        $int = $conn->query("UPDATE`blaise_set` SET ddesc='$desc' WHERE bid='$id' ");
        if($int){
            $_SESSION['msgs']="Updated suceessfully";
            header("Location:settings");
        }else{
            $_SESSION['msg']="Oops!, try again later"; 
            header("Location:settings");
        }
    

    }
       


endif;




    function test_values($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        // $data = empty($data);
        return $data;
    }





?>