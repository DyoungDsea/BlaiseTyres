                    <ul class="account-nav__list">
                        <li class="account-nav__item account-nav__item--active"><a href="dashboard">Dashboard</a></li>
                        <li class="account-nav__item"><a href="account-profile">Edit Profile</a></li>
                        <li class="account-nav__item"><a href="history">Withdrawal History</a></li>
                        <li class="account-nav__item"><a href="account-direct-purchases">My Direct Purchases </a></li>
                        <li class="account-nav__item"><a href="account-subscription-plan">My Subscriptions </a></li>
                        <li class="account-nav__item"><a href="account-shipping-address">My Shipping Addresses </a></li>
                        <li class="account-nav__item"><a href="account-payment-history">Payment History </a></li>
                        <li class="account-nav__item"><a href="account-password">Change Password</a></li>
                        <li class="account-nav__divider" role="presentation"></li>
                        <li class="account-nav__item"><a href="logout">Logout</a></li>
                    </ul>