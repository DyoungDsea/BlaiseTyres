<style>
.wine{
    margin-top:20px;
}
</style>
<div class="row" style="padding:50px 35px;">
<div class="col-md-2 col-sm-4 wine" align="center">
<a class="" href="#"><img style="width:150px;height:50px;" src="images/clients/brand6.jpg" alt="..."></a>
</div>
<div class="col-md-2 col-sm-4 wine" align="center">
<a class="" href="#"><img style="width:150px;height:50px;" src="images/clients/brand5.jpg" alt="..."></a>
</div>
<div class="col-md-2 col-sm-4 wine" align="center">
<a class="" href="#"><img style="width:150px;height:50px;" src="images/clients/brand1.jpg" alt="..."></a>
</div>
<div class="col-md-2 col-sm-4 wine" align="center">
<a class="" href="#"><img style="width:150px;height:50px;" src="images/clients/brand2.jpg" alt="..."></a>
</div>
<div class="col-md-2 col-sm-4 wine" align="center">
<a class="" href="#"><img style="width:150px;height:30px;margin-top:8px;" src="images/clients/brand7.jpg" alt="..."></a>
</div>
<div class="col-md-2 col-sm-4 wine" align="center">
<a class="" href="#"><img style="width:150px;height:50px;" src="images/clients/brand8.png" alt="..."></a>
</div>
</div>