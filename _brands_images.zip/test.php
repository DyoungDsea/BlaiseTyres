<?php
require 'conn.php';

// session_start();
// echo $_SESSION['grand'];



// function discount($num, $price){
//     $nums = ((Float)$num / 100) * $price;
//     $nums = $price - $nums;
//     return $nums;
// }


// echo discount(0, 20000);
// echo floor("3.6");


?>