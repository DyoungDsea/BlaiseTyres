<?php
session_start();

if(isset($_POST['Address'])){
    $message = $_POST['message'];
    $_SESSION["Address"] = $message;
}