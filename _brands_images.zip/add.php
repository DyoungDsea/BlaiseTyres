<?php
session_start();

$top ='';
$tops ='';
$state = '';

	if (isset($_POST["SumTotal"])) {        
        $id = (Float)$_POST['id'];
        $total = 0;
        foreach($_SESSION["subscribe"] as $keys => $values){
           $total += $id;
           
        }
        $tops .= '&#8358;'.number_format($total,2);
        if(isset($_SESSION['coupons'])){
            $totals =((Float)$_SESSION['coupons'] + $total);
            $_SESSION['grand']= $totals;
        }else{
            $totals =((Float)$_SESSION['total'] + $total);
            $_SESSION['grand']=(Float)$_SESSION['total'] + $total;
        }
        $top .=  '&#8358;'.number_format($totals,2);


        $_SESSION['location']=$_POST['text'];
        $_SESSION['cost']=$total;
        $_SESSION['costs']=$id;

        $state .='<textarea name="" placeholder="Enter Address" id="sub-address" class="form-control mt-2"></textarea>';
		
    }
    
    $out = array(
        'top'=> $top,
        'tops'=> $tops,
        'station'=> $state
    );

    echo json_encode($out);

?>